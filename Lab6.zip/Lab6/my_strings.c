/*
    CSC 325-02
    Lab 6 - my_strings.c
    Name: Praneel Pothukanuri
    Email: pothukp1@tcnj.edu
*/

#include "my_strings.h"
#include <stdio.h>
#include <stdlib.h>
size_t strlen(const char *s)
{
    unsigned long count = 0;
    while(s[count] != 0)
    {
        count+=1;
    }
    return count;
}



char *strcat(char *restrict dst, const char *restrict src)
{   
    int srclen = strlen(src);
    int pos = strlen(dst);

    for(int i = 0; i<srclen; i++)
    {
        dst[pos] = src[i];
        pos+=1;
    }
    dst[pos] = 0;
    return dst;
}
//return an integer greater than, equal to, or less than 0, according as the string s1 is greater than, equal to, or less than the string s2.
int strcmp(const char *s1, const char *s2) 
{
    int len1 = strlen(s1);
    int len2 = strlen(s2);

    int pos = 0;
    while(pos<len1 && pos<len2)
    {
        if(s1[pos]<s2[pos])
        {
            return -1;
        }
        else if(s1[pos]>s2[pos])
        {
            return 1;
        }
        pos++;
    }

    if(s1[pos] == 0 && s2[pos] == 0)
    {
        return 0;
    }
    else if(s1[pos] == 0)
    {
        return -1;
    }
    else{
        return 1;
    }
}



char *strchr(const char *s, int c)
{
    const char *found = NULL;
    if(c == 0)
    {
        found = s+strlen(s);
        return (char *)found;
    }
    for(int i = 0; i<strlen(s); i++)
    {
        if(s[i] == c)
        {
            found = s+i;
            return (char *)found;
        }
    }
    return (char *)found;
}

char *strcpy(char *restrict dst, const char *restrict src) //copy the string src to dst(including the terminating character)
{
    int dstLen = strlen(dst);
    int srcLen = strlen(src);
    
    int pos;
    for(pos = 0; pos<srcLen; pos++)
    {
        dst[pos] = src[pos];
    }
    
    for(int i = pos; i<=dstLen; i++)
    {
        dst[i] = 0;
    }
    return dst;
}

char *strdup(const char *s)
{
    int len = 0;
    len = strlen(s);

    char *duplicate = NULL;
    duplicate = (char *)(calloc(len+1, sizeof(char)));

    if(duplicate == NULL)
    {
        return NULL;
    }
    strcpy(duplicate, s);
    return duplicate;
}

char *strstr(const char *haystack, const char *needle)
{
    const char *found = NULL;
    int Needlelen = strlen(needle);
    int Haystacklen = strlen(haystack);

    if(Needlelen == 0)
    {
        found = haystack;
        return (char *)found;
    }

    int pos = 0;
    while(pos < Haystacklen)
    {
        if(haystack[pos] == needle[0])
        {
            int i = 0;
            while(i<Needlelen)
            {
                if(pos+i < Haystacklen)
                {
                    if(haystack[pos+i] != needle[i])
                    {
                        break;
                    }
                    i+=1;
                }
                else
                {
                    break;
                }
            }
            if(i == strlen(needle))
            {
                found = haystack + pos;
                return (char *)found;
            }
        }
        pos+=1;
    }
    return (char *)found;
}