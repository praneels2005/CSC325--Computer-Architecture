/*
    CSC 325-02
    Lab 6 - stringtester.c
    Name: Praneel Pothukanuri
    Email: pothukp1@tcnj.edu
*/

#include "my_strings.h"
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) 
{
    char str[64] = "";
    char str2[64] = "";
    char dest[64] = "Hello";
    char str3[64] = "This is empty";
    const char *str4 = "Yes";
    const char *str5 = "A very large string";
    char *dup1 = NULL;
    char *dup2 = NULL;


    //strcat - TestCase1
    if(strcmp(", World" , strcat(str, ", World")) != 0)
    {
        printf("strcat 1");
    }


    //strcat - TestCase2
    if(strcmp("Hello, World", strcat(dest, ", World")) != 0)
    {
        printf("strcat 2");
    }



    //strchr - TestCase1
    if(strcmp("orial", strchr("tutorial", 'o')) != 0)
    {
        printf("strchr 1");
    }



    //strchr - TestCase2
    if(strcmp("d", strchr("Hello World", 'd')) != 0)
    {
        printf("strchr 2");
    }


    //strchr - TestCase3
    if(NULL != strchr("Coding", 'h'))
    {
        printf("strchr 3");
    }

    //strchr - TestCase4
    if(0 == strchr("Hello World", '\0'))
    {
        printf("strchr 4");
    }


    //strcmp - TestCase1
    if(strcmp("hello", "Hello") <=0)
    {
        printf("strcmp 1");
    }

    //strcmp - TestCase2
    if(strcmp("Hello world", "Hello world") != 0)
    {
        printf("strcmp 2");
    }

    //strcpy - TestCase1
    if(strcmp("Hello", strcpy(str2, "Hello")) != 0)
    {
        printf("strcpy 1");
    }

    //strcpy - TestCase2
    if(strcmp("Coding Rocks", strcpy(str3, "Coding Rocks")) != 0)
    {
        printf("strcpy 2");
    }

    //strdup - TestCase1
    //char *dup1 = strdup(str4);
    dup1 = strdup(str4);
    if(strcmp("Hello", dup1) >= 0)
    {
        printf("strdup 1");
    }
    free(dup1);
    dup1 = NULL;

    //strdup - TestCase2
    dup2 = strdup(str5);
    if(strcmp("A very large string", dup2) != 0)
    {
        printf("strdup 2");
    }
    free(dup2);
    dup2 = NULL;

    //strlen - TestCase1
    if(strlen("he\0lo") != 2)
    {
        printf("strlen 1");
    }

    //strlen - TestCase2
    if(strlen("") != 0)
    {
        printf("strlen 2");
    }

    //strlen - TestCase3
    const char * ptr = NULL;
    if(strlen(ptr) != 0)
    {
        printf("strlen 2");
    }

    //strstr - TestCase1
    if(strcmp("Bar Baz", strstr("Foo Bar Baz", "Bar")) != 0)
    {
        printf("strstr 1");
    }
    
    //strstr - TestCase2
    if(strstr("Foo Bar Baz", "Hello") != NULL)
    {
        printf("strstr 2");
    }
    return 0;
}