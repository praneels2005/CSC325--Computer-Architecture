#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "readfile.h"

void get_filename_from_cmdline(int argc, char *argv[], char *filename) {
    if (argc != 2) {
        fprintf(stderr, "usage: %s filename\n", argv[0]);
        exit(1);
    }
    else {
        strncpy(filename, argv[1], 255);
    }

    
}

//array of float values that stores the values read in from the file
float *get_values(int *size, int *capacity, char *filename) 
{
    *capacity = 20;
    float *arr = malloc((*capacity)*sizeof(float));
    if(arr == NULL)
    {
        printf("Error: malloc failed\n");
        exit(1);
    }
    
    float value;
    if(open_file(filename) == 0)
    {
        while(read_float(&value) == 0)
        {
            if(*size >= *capacity)
            {
                
                float *arr1 = malloc(2*(*capacity)*sizeof(float));
                if(arr1 == NULL)
                {
                    printf("Error: malloc failed\n");
                    free(arr);
                    exit(1);
                }
                memcpy(arr1, arr, *capacity*sizeof(float));
                *capacity *= 2;
                free(arr);
                arr = arr1;
            }
    
                arr[*size] = value;

                //post incremenent size to include first element in array
                *size = *size+1;
        }
    }
    fclose(filename);
    return arr;
    
}

void bubbleSort(float *values,int sizeOfArray)
{
    for(int i = 0; i<(sizeOfArray)-1; i++)
    {
        for(int j = 0; j<(sizeOfArray)-1-i; j++)
        {
            if(values[j] > values[j+1])
            {
                //swap
                float temp = values[j];
                values[j] = values[j+1];
                values[j+1] = temp;
            }
        }
    }
}

//array is dynamically allocated with size = 20.
void fiveNumSummary(float *values, int sizeOfArray, int size)
{
    float sum = 0;
    double mean;
    float min, max,median,StdDev;

    //mean
    for(int i = 0; i< size; i++)
    {
        sum+= values[i];
    }
    mean = sum/size;

    //minimum
    min = max = *values;
    for(int i = 1; i< size; i++)
    {
        if(min >values[i])
        {
            min = values[i];
        }
        if(max <values[i])
        {
            max = values[i];
        }
    }
    

    //Median
    if(size %2 == 0)
    {
        int index = size/2;
        median = values[ index];
    }
    else
    {
        int index = (size/2)+1;
        median = values[ index];
    }

    float tempSum = 0.0; 
    //Standard Deviation
    for(int i = 0; i<size; i++)
    {
        tempSum += pow(values[i]-mean,2);
    }

    StdDev = sqrt(tempSum/(size-1));

    

    printf("Results:\n-------\n");
    printf("num Values:\t%d\n",size);
    printf("min:\t%.3f\n",min);
    printf("max:\t%.3f\n",max);
    printf("mean:\t%.3f\n",mean);
    printf("median:\t%.3f\n",median);
    printf("std dev:\t%.3f\n",StdDev);
    printf("unused array capacity:\t%d\n",sizeOfArray- size);
}

void printArray(float *values,int size)
{
    for(int i =0; i< size; i++)
    {
        printf("%.1f\n", values[i]);
    }
}

int main(int argc, char *argv[]) 
{
    char filename[255];
    int size = 0; //number of elements that are currently being used or stored in the array
    int capacity = 0; //total number of elements that the array can hold based on the amount of memory you allocated

    // get the filename from the command line
    get_filename_from_cmdline(argc, argv, filename);
       
    float *ARRAY = get_values(&size, &capacity, filename);
    if(ARRAY == NULL)
    {
        printf("Error: malloc failed\n");
        exit(1);
    }

    bubbleSort(ARRAY, size);
    //printArray(ARRAY, size);
    printf("\n");
    fiveNumSummary(ARRAY, capacity,size);

    


    return 0;
}