/*
    CSC 325-01
    Lab 2, Part 2
    Name: Praneel Pothukanuri
    Email: pothukp1@tcnj.edu
*/
#include <stdio.h>
#include <math.h>
//Example values listed as global values
unsigned int val1 = 97;
unsigned int val2 = 56;
unsigned int val3 = 210;
void question1()
{
    int val;
    val = 97;
    printf("The answer to question 1, displaying values in different ways, is shown through the following example:");
    printf("\nGiven the int %d -->\nCharacter: %c \nFloat Value: %f \nHexadecimal Value: 0x%x \n",val, (char)val, (float)val, val);
}

//double pow(double x, double y)
//int = 4 bytes = 32 bits
void question2()
{
    printf("\nThe answer to question 2, assuming the size of an int is 4 bytes, or 32 bits, the maximum value that can be stored in a C unsigned int variable is: %f", pow(2.0 , 32.0)-1.0);
}

void question3()
{
    printf("\nThe answer to question 3, assuming the size of an int is 4 bytes, or 32 bits, the maximum positive value that can be stored in a C signed int variable is: %f", pow(2.0 , 32-1.0)-1.0);
}

//The user must enter the desired number of left shifts as an input for the function
void question4(int leftshifts)
{
    printf("\n");
    printf("\nThe answer to question 4, The arithmetic operation to shifting an unsigned int value, val, by 1 left shift is val * 2^1");
    printf("\nExample 1: %u shifted to the left by value 1 is %u, in other words %u * %f",val1, val1<<1,val1,pow(2.0,leftshifts));
    printf("\nExample 2: %u shifted to the left by value 1 is %u, in other words %u * %f",val2, val2<<1,val2,pow(2.0,leftshifts));
    printf("\nExample 3: %u shifted to the left by value 1 is %u, in other words %u * %f",val3, val3<<1,val3,pow(2.0,leftshifts));
}

void question5(int leftshifts)
{
    printf("\n");
    printf("\nThe answer to question 5, the arithmetic operation to shifting an unsigned int value, val, to the left by value 2 is val * 2^2");
    printf("\nExample 1: %u shifted to the left by value 2 is %u, in other words %u * %f",val1, val1<<2,val1,pow(2.0,leftshifts));
    printf("\nExample 2: %u shifted to the left by value 2 is %u, in other words %u * %f",val2, val2<<2,val2,pow(2.0,leftshifts));
    printf("\nExample 3: %u shifted to the left by value 2 is %u, in other words %u * %f",val3, val3<<2,val3,pow(2.0,leftshifts));
}

//The user must enter the desired number of right shifts as an input for the function
void question6(int rightshifts)
{
    printf("\n");
    printf("\nThe answer to question 6, the arithmetic operation to shifting an unsigned int value, val, to the right by value 1 is val/2^1");
    printf("\nExample 1: %u shifted to the right by value 1 is %u, in other words %u / %f",val1, val1>>1,val1,pow(2.0,rightshifts));
    printf("\nExample 2: %u shifted to the right by value 1 is %u, in other words %u / %f",val2, val2>>1,val2,pow(2.0,rightshifts));
    printf("\nExample 3: %u shifted to the right by value 1 is %u, in other words %u / %f",val3, val3>>1,val3,pow(2.0,rightshifts));
}

int main(int argc, char *argv[]) 
{
    question1();
    question2();
    question3();
    question4(1);
    question5(2);
    question6(1);

}