#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "readfile.h"

#define ARRAYSIZE 100

void get_filename_from_cmdline(int argc, char *argv[], char *filename) 
{
    
    if (argc != 2) {
        fprintf(stderr, "usage: %s filename\n", argv[0]);
        exit(1);
    }
    else {
        
        strncpy(filename, argv[1], 255);
    }
}
//sizeof(values) prints the total memory occupied by the array
//sizeof(values[0]) prints the size of one element of the array(floats allocate 4 bytes of memory)
//total amont of space occupied by an array/amount of space by one of the elements(bytes)
/*
sizeof(point)/sizeof(point[0]) trick doesn't work for a dynamically allocated array, only an array allocated on the stack
*/

//additional parameter "sizeOfArray" is introduced as C does not have built in size functions for arrays. 
//Additionally, sizeof(point)/sizeof(point[0]) does not work for a dynamically allocated array, only for arrays allocated on the stack such as values in the main method
void bubbleSort(float values[],int sizeOfArray)
{
    //BubbleSort range required to be edited as the starting index was not accounted in the sort
    for(int i = 0; i<(sizeOfArray)-1; i++)
    {
        for(int j = 0; j<(sizeOfArray)-1-i; j++)
        {
            if(values[j] > values[j+1])
            {
                //swap
                float temp = values[j];
                values[j] = values[j+1];
                values[j+1] = temp;
            }
        }
    }
}



int main(int argc, char *argv[]) {
    char filename[255];
    float values[ARRAYSIZE];

    //variables to allocate the values read from the file
    int size;
    float min;
    float max;
    float val;

    // get the filename from the command line
     get_filename_from_cmdline(argc, argv, filename);
     
    
    printf("Reading file named %s",filename);
    //file is declared with values if returned int is 0, indicating true
    if(open_file(filename) == 0)
    {
        //Built in methods have return type ints which return either 0(true), or -1(false, or reached the EOF), which do not need to be displayed
        //Built in methods use fscanf, which allocates the nearest corresponding data type to a variable starting from its new position
        read_int(&size); //locates closest int in file
        read_float(&min); //locates closest float in file
        read_float(&max); //locates next closest float in file
    }
    else
    {
        printf("File is unable to open");
    }

    printf("\nThe file has %d floats ranging from %.2f to %.2f ",size, min, max);

//Used to keep track of indices in values array
int index = 0;

//while loop traverses through file, locating float data type values in the file until it reaches EOF
    while(read_float(&val) == 0)
    {
        //assigning the value to an index in the array
        values[index] = val;
        index++;
    }
    
    printf("\nThe unsorted values are: ");
    for(int i = 0; i<size; i++)
    {
        printf("%.2f ", values[i]);
    }
    bubbleSort(values, size);
    printf("\nThe sorted values are: ");
    for(int i = 0; i<size; i++)
    {
        printf("%.2f ", values[i]);
    }  
    return 0;
}